export const worshipTypeLabel: Record<string, string> = {
  ANCESTOR_LINE: "歷代祖先",
  INDIVIDUAL: "個人往生者",
};

// 新增祭祀資料表單用的下拉選項（依需求只支援這兩種）
export const worshipTypeOptions: { value: "ANCESTOR_LINE" | "INDIVIDUAL"; label: string }[] = [
  { value: "ANCESTOR_LINE", label: "歷代祖先" },
  { value: "INDIVIDUAL", label: "個人乙位正魂" },
];

export const activityTypeLabel: Record<string, string> = {
  ANNUAL_LANTERN: "年度燈",
  UNIVERSAL_SALVATION: "普渡",
  TEMPLE_CELEBRATION: "宮慶",
  REPRINT: "補印",
};

// V2.0 祭祀資料核心（RitualRecord）用的標籤
export const ritualRecordStatusLabel: Record<string, string> = {
  DRAFT: "草稿",
  CONFIRMED: "已確認",
  CANCELLED: "已取消",
};

export const universalSalvationEntryCategoryLabel: Record<string, string> = {
  ANCESTOR_LINE: "歷代祖先",
  INDIVIDUAL_SOUL: "個人乙位正魂",
  DEBT_CREDITOR: "冤親債主",
  UNBORN_CHILD: "無緣子女",
};

// 列印時四個類別固定的顯示順序（型別故意不寫死成 keyof typeof
// universalSalvationEntryCategoryLabel——那個物件的宣告型別是 Record<string,
// string>，keyof 出來只會是寬鬆的 string，套進 Prisma 產生的精確 enum 型別會
// 編譯失敗。真正需要精確 enum 型別的地方，見 src/lib/ritual.ts 裡另外定義的
// ENTRY_CATEGORY_ORDER。這裡只保留給純顯示用途（例如畫面下拉選單）。
export const universalSalvationEntryCategoryOrder = [
  "ANCESTOR_LINE",
  "INDIVIDUAL_SOUL",
  "DEBT_CREDITOR",
  "UNBORN_CHILD",
] as const;

export const memberRoleLabel: Record<string, string> = {
  HOUSEHOLD_HEAD: "戶長",
  SPOUSE: "配偶",
  SON: "兒子",
  DAUGHTER: "女兒",
  FATHER: "父親",
  MOTHER: "母親",
  GRANDFATHER: "祖父",
  GRANDMOTHER: "祖母",
  OTHER: "其他",
};

// 新增家人表單用的下拉選項，順序依需求給定的順序
export const memberRoleOptions: { value: keyof typeof memberRoleLabel; label: string }[] = [
  { value: "HOUSEHOLD_HEAD", label: "戶長" },
  { value: "SPOUSE", label: "配偶" },
  { value: "SON", label: "兒子" },
  { value: "DAUGHTER", label: "女兒" },
  { value: "FATHER", label: "父親" },
  { value: "MOTHER", label: "母親" },
  { value: "GRANDFATHER", label: "祖父" },
  { value: "GRANDMOTHER", label: "祖母" },
  { value: "OTHER", label: "其他" },
];
