import { Prisma, UniversalSalvationEntryCategory } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { universalSalvationEntryCategoryLabel } from "@/lib/labels";

/**
 * V2.0「祭祀資料核心」的業務邏輯統一寫在這裡（route.ts 只負責解析請求/回傳，
 * 邏輯集中在 lib，方便未來普渡以外的模組——年度燈、宮慶——共用同一套模式）。
 */

// 列印時四個類別固定的顯示順序。刻意直接標註成 Prisma 產生的
// UniversalSalvationEntryCategory[]（而不是從 labels.ts 的 Record<string,
// string> 用 keyof 推導），避免型別被寬鬆成 string 導致 build 失敗
// （2026-07-15 部署時實際遇到這個錯誤，已修正）。
const ENTRY_CATEGORY_ORDER: UniversalSalvationEntryCategory[] = [
  "ANCESTOR_LINE",
  "INDIVIDUAL_SOUL",
  "DEBT_CREDITOR",
  "UNBORN_CHILD",
];

// 一筆普渡登記主檔 + 明細 + 登記項目，撈出來時固定用這個 include 形狀
const universalSalvationInclude = {
  universalSalvation: {
    include: {
      entries: { orderBy: [{ category: "asc" }, { sortOrder: "asc" }, { createdAt: "asc" }] },
    },
  },
} satisfies Prisma.RitualRecordInclude;

export type UniversalSalvationRecordView = Prisma.RitualRecordGetPayload<{
  include: typeof universalSalvationInclude;
}>;

/** 取得某戶、某年度的普渡登記完整資料（主檔＋明細＋登記項目）。找不到回傳 null。 */
export async function getUniversalSalvationRecord(
  householdId: string,
  year: number
): Promise<UniversalSalvationRecordView | null> {
  return prisma.ritualRecord.findUnique({
    where: {
      householdId_year_activityType: {
        householdId,
        year,
        activityType: "UNIVERSAL_SALVATION",
      },
    },
    include: universalSalvationInclude,
  });
}

export type CopyUniversalSalvationResult =
  | { ok: true; record: UniversalSalvationRecordView }
  | { ok: false; status: number; error: string };

/**
 * 「複製去年資料」：把來源年度（預設是目標年度的前一年）的普渡登記整組
 * （主檔＋明細＋所有登記項目）複製成新的一筆，來源那筆完全不受影響。
 *
 * 設計上的兩個預設值（若未來實際使用上不符合需求，麻煩再跟我們確認調整）：
 * 1. 目標年度如果已經有資料，不會覆蓋，直接回傳錯誤——「彼此互不覆蓋」。
 * 2. 複製後的新一筆，狀態固定重設為 DRAFT、「是否報名普渡」重設為 false，
 *    因為換了新年度，需要重新確認/報名，不會因為複製就直接視為已確認。
 *    其餘欄位（陽上姓名、安奉位置、贊普、普渡桌、備註、所有登記項目）原樣複製，
 *    當作今年資料輸入的起點。
 */
export async function copyUniversalSalvationFromPreviousYear(
  householdId: string,
  targetYear: number,
  sourceYear?: number
): Promise<CopyUniversalSalvationResult> {
  const household = await prisma.household.findUnique({ where: { id: householdId } });
  if (!household) {
    return { ok: false, status: 404, error: "找不到這個家戶" };
  }

  const fromYear = sourceYear ?? targetYear - 1;

  const existingTarget = await prisma.ritualRecord.findUnique({
    where: {
      householdId_year_activityType: {
        householdId,
        year: targetYear,
        activityType: "UNIVERSAL_SALVATION",
      },
    },
  });
  if (existingTarget) {
    return {
      ok: false,
      status: 409,
      error: `${targetYear} 年的普渡資料已經存在，不會覆蓋既有資料`,
    };
  }

  const source = await getUniversalSalvationRecord(householdId, fromYear);
  if (!source || !source.universalSalvation) {
    return { ok: false, status: 404, error: `找不到 ${fromYear} 年的普渡資料，無法複製` };
  }

  const created = await prisma.ritualRecord.create({
    data: {
      householdId,
      memberId: source.memberId,
      year: targetYear,
      activityType: "UNIVERSAL_SALVATION",
      status: "DRAFT",
      notes: source.notes,
      universalSalvation: {
        create: {
          isRegistered: false,
          yangshangName: source.universalSalvation.yangshangName,
          enshrinementLocation: source.universalSalvation.enshrinementLocation,
          isSponsor: source.universalSalvation.isSponsor,
          sponsorQuantity: source.universalSalvation.sponsorQuantity,
          sponsorUnitPrice: source.universalSalvation.sponsorUnitPrice,
          sponsorAmount: source.universalSalvation.sponsorAmount,
          sponsorNotes: source.universalSalvation.sponsorNotes,
          tableNumber: source.universalSalvation.tableNumber,
          notes: source.universalSalvation.notes,
          entries: {
            create: source.universalSalvation.entries.map((entry) => ({
              category: entry.category,
              displayName: entry.displayName,
              yangshangName: entry.yangshangName,
              worshipRecordId: entry.worshipRecordId,
              sortOrder: entry.sortOrder,
              notes: entry.notes,
            })),
          },
        },
      },
    },
    include: universalSalvationInclude,
  });

  return { ok: true, record: created };
}

export type DeleteUniversalSalvationResult =
  | { ok: true }
  | { ok: false; status: number; error: string };

/**
 * 刪除某戶、某年度的普渡登記（主檔，會連帶刪除明細與所有登記項目）。
 *
 * 這支主要是給「部署驗收/API 測試」清除本次測試建立的臨時祭祀資料用——
 * 這一版還沒有普渡畫面，正式的刪除/作廢流程之後在畫面上開發時再一併設計
 * （例如是否要跟財務作廢一樣留稽核紀錄、是否要改成軟刪除）。這裡只刪
 * RitualRecord 本身，不會動到 Household／Member。
 */
export async function deleteUniversalSalvationRecord(
  householdId: string,
  year: number
): Promise<DeleteUniversalSalvationResult> {
  const existing = await prisma.ritualRecord.findUnique({
    where: {
      householdId_year_activityType: {
        householdId,
        year,
        activityType: "UNIVERSAL_SALVATION",
      },
    },
  });
  if (!existing) {
    return { ok: false, status: 404, error: `找不到 ${year} 年的普渡資料` };
  }

  await prisma.ritualRecord.delete({ where: { id: existing.id } });
  return { ok: true };
}

export type UniversalSalvationPrintEntry = {
  displayName: string;
  yangshangName: string | null;
  notes: string | null;
};

export type UniversalSalvationPrintData = {
  household: { id: string; name: string };
  year: number;
  yangshangName: string | null;
  enshrinementLocation: string | null;
  isSponsor: boolean;
  sponsorQuantity: number | null;
  sponsorUnitPrice: Prisma.Decimal | null;
  sponsorAmount: Prisma.Decimal | null;
  sponsorNotes: string | null;
  tableNumber: string | null;
  categories: {
    category: UniversalSalvationEntryCategory;
    categoryLabel: string;
    entries: UniversalSalvationPrintEntry[];
  }[];
};

/**
 * 建立列印用的資料格式（本次只需要資料格式，不產生 PDF）。
 * 依固定順序（歷代祖先 → 個人乙位正魂 → 冤親債主 → 無緣子女）把登記項目分類。
 */
export async function getUniversalSalvationPrintData(
  householdId: string,
  year: number
): Promise<UniversalSalvationPrintData | null> {
  const household = await prisma.household.findUnique({ where: { id: householdId } });
  if (!household) return null;

  const record = await getUniversalSalvationRecord(householdId, year);
  if (!record || !record.universalSalvation) return null;

  const detail = record.universalSalvation;
  const entriesByCategory = new Map<UniversalSalvationEntryCategory, UniversalSalvationPrintEntry[]>();
  for (const entry of detail.entries) {
    const list = entriesByCategory.get(entry.category) ?? [];
    list.push({
      displayName: entry.displayName,
      yangshangName: entry.yangshangName,
      notes: entry.notes,
    });
    entriesByCategory.set(entry.category, list);
  }

  return {
    household: { id: household.id, name: household.name },
    year,
    yangshangName: detail.yangshangName,
    enshrinementLocation: detail.enshrinementLocation,
    isSponsor: detail.isSponsor,
    sponsorQuantity: detail.sponsorQuantity,
    sponsorUnitPrice: detail.sponsorUnitPrice,
    sponsorAmount: detail.sponsorAmount,
    sponsorNotes: detail.sponsorNotes,
    tableNumber: detail.tableNumber,
    categories: ENTRY_CATEGORY_ORDER.map((category) => ({
      category,
      categoryLabel: universalSalvationEntryCategoryLabel[category],
      entries: entriesByCategory.get(category) ?? [],
    })),
  };
}
