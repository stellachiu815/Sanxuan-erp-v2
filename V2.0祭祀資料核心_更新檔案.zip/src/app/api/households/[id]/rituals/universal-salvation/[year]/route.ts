import { NextRequest, NextResponse } from "next/server";
import { deleteUniversalSalvationRecord, getUniversalSalvationRecord } from "@/lib/ritual";

/**
 * 查詢某戶、某年度的普渡登記資料（主檔＋明細＋歷代祖先/個人乙位正魂/
 * 冤親債主/無緣子女登記項目）。
 *
 * GET /api/households/F00009/rituals/universal-salvation/115
 *
 * 這一版「祭祀資料核心」只建立資料模型與 API，沒有畫面；這支 GET 主要
 * 用來檢查資料是否正確寫入／複製成功。之後普渡模組的畫面會直接呼叫這支。
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string; year: string }> }
) {
  const { id: householdId, year: yearParam } = await params;

  const year = Number(yearParam);
  if (!Number.isInteger(year)) {
    return NextResponse.json({ error: "年度格式錯誤" }, { status: 400 });
  }

  const record = await getUniversalSalvationRecord(householdId, year);
  if (!record) {
    return NextResponse.json(
      { error: `找不到 ${year} 年的普渡資料` },
      { status: 404 }
    );
  }

  return NextResponse.json({ record });
}

/**
 * 刪除某戶、某年度的普渡登記（連帶刪除明細與登記項目，不會動到家戶本身）。
 *
 * DELETE /api/households/F00009/rituals/universal-salvation/115
 *
 * 這支目前主要用途是「部署驗收/API 測試」時，清除測試建立的臨時祭祀資料——
 * 這一版還沒有普渡畫面，正式的刪除/作廢流程之後開發畫面時再一併設計。
 */
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string; year: string }> }
) {
  const { id: householdId, year: yearParam } = await params;

  const year = Number(yearParam);
  if (!Number.isInteger(year)) {
    return NextResponse.json({ error: "年度格式錯誤" }, { status: 400 });
  }

  const result = await deleteUniversalSalvationRecord(householdId, year);
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: result.status });
  }

  return NextResponse.json({ ok: true });
}
