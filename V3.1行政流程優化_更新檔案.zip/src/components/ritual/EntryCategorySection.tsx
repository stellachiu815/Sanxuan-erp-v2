"use client";

import { useState } from "react";
import {
  inputClass,
  labelClass,
  primaryButtonClass,
  secondaryButtonClass,
  errorTextClass,
} from "@/components/household/formStyles";
import EntryRow from "./EntryRow";
import type { EntryAddMode, EntryCategory, EntryJSON, RecordJSON } from "./types";

type Props = {
  householdId: string;
  year: number;
  category: EntryCategory;
  title: string;
  tone: string;
  addMode: EntryAddMode;
  fixedDisplayName?: string;
  entries: EntryJSON[];
  onRecordUpdated: (record: RecordJSON) => void;
};

/**
 * 一個登記分類的區塊（例如「歷代祖先」），列出目前的登記項目、可新增/編輯/刪除。
 *
 * V3.1「行政流程優化」：新增的填寫方式依分類不同（見 types.ts 的 addMode 說明），
 * 目的是讓行政人員新增時符合實際填寫習慣（例如歷代祖先只需要打姓氏）。
 * 名稱組成規則只在這裡（畫面）處理，送到後端的 API 完全沒有變，一律還是傳完整的
 * displayName 字串。
 */
export default function EntryCategorySection({
  householdId,
  year,
  category,
  title,
  tone,
  addMode,
  fixedDisplayName,
  entries,
  onRecordUpdated,
}: Props) {
  async function postEntry(payload: {
    displayName: string;
    yangshangName?: string | null;
    notes?: string | null;
  }) {
    const res = await fetch(
      `/api/households/${householdId}/rituals/universal-salvation/${year}/entries`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ category, ...payload }),
      }
    );
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error ?? "新增失敗，請稍後再試一次。");
    }
    return data.record as RecordJSON;
  }

  return (
    <div className={`rounded-2xl p-5 ${tone}`}>
      <div className="flex items-center justify-between">
        <h3 className="text-base font-medium text-ink">{title}</h3>
        <span className="rounded-full bg-white/70 px-2 py-0.5 text-xs text-ink-soft">
          {entries.length} 筆
        </span>
      </div>

      <div className="mt-3 flex flex-col gap-2">
        {entries.length === 0 && (
          <p className="text-sm text-ink-faint">尚無登記項目。</p>
        )}
        {entries.map((entry) => (
          <EntryRow
            key={entry.id}
            householdId={householdId}
            year={year}
            entry={entry}
            onRecordUpdated={onRecordUpdated}
          />
        ))}
      </div>

      {addMode === "instant" && (
        <InstantAddButton
          title={title}
          fixedDisplayName={fixedDisplayName ?? title}
          onAdd={() => postEntry({ displayName: fixedDisplayName ?? title })}
          onRecordUpdated={onRecordUpdated}
        />
      )}

      {addMode === "surname" && (
        <SurnameAddForm title={title} onAdd={postEntry} onRecordUpdated={onRecordUpdated} />
      )}

      {addMode === "name" && (
        <NameAddForm title={title} onAdd={postEntry} onRecordUpdated={onRecordUpdated} />
      )}
    </div>
  );
}

/** 冤親債主／無緣子女：不用輸入任何文字，按一下就直接建立固定名稱的一筆。 */
function InstantAddButton({
  title,
  fixedDisplayName,
  onAdd,
  onRecordUpdated,
}: {
  title: string;
  fixedDisplayName: string;
  onAdd: () => Promise<RecordJSON>;
  onRecordUpdated: (record: RecordJSON) => void;
}) {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleClick() {
    setSubmitting(true);
    setError(null);
    try {
      const record = await onAdd();
      onRecordUpdated(record);
    } catch (err) {
      setError(err instanceof Error ? err.message : "網路錯誤，請稍後再試一次。");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mt-3">
      <button
        type="button"
        onClick={handleClick}
        disabled={submitting}
        className="w-full rounded-xl bg-white/70 px-4 py-2 text-sm text-ink-soft transition hover:bg-white disabled:opacity-50"
      >
        {submitting ? "新增中…" : `＋ 新增${fixedDisplayName}`}
      </button>
      {error && <p className={`mt-2 ${errorTextClass}`}>{error}</p>}
    </div>
  );
}

/** 歷代祖先：只填姓氏，自動組成「○○姓歷代祖先」。 */
function SurnameAddForm({
  title,
  onAdd,
  onRecordUpdated,
}: {
  title: string;
  onAdd: (payload: { displayName: string; notes?: string | null }) => Promise<RecordJSON>;
  onRecordUpdated: (record: RecordJSON) => void;
}) {
  const [adding, setAdding] = useState(false);
  const [surname, setSurname] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function reset() {
    setAdding(false);
    setError(null);
    setSurname("");
    setNotes("");
  }

  async function handleAdd() {
    const trimmedSurname = surname.trim();
    if (!trimmedSurname) {
      setError("請輸入姓氏");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const record = await onAdd({
        displayName: `${trimmedSurname}姓歷代祖先`,
        notes: notes.trim() || null,
      });
      onRecordUpdated(record);
      reset();
    } catch (err) {
      setError(err instanceof Error ? err.message : "網路錯誤，請稍後再試一次。");
    } finally {
      setSubmitting(false);
    }
  }

  if (!adding) {
    return (
      <button
        type="button"
        onClick={() => setAdding(true)}
        className="mt-3 w-full rounded-xl bg-white/70 px-4 py-2 text-sm text-ink-soft transition hover:bg-white"
      >
        ＋ 新增{title}
      </button>
    );
  }

  return (
    <div className="mt-3 flex flex-col gap-2 rounded-xl bg-white/80 p-4">
      <div>
        <label className={labelClass}>姓氏</label>
        <div className="flex items-center gap-2">
          <input
            className={inputClass}
            value={surname}
            onChange={(e) => setSurname(e.target.value)}
            placeholder="例如：王"
            maxLength={10}
            autoFocus
          />
          {surname.trim() && (
            <span className="whitespace-nowrap text-sm text-ink-faint">
              → {surname.trim()}姓歷代祖先
            </span>
          )}
        </div>
      </div>
      <div>
        <label className={labelClass}>備註（選填）</label>
        <input className={inputClass} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </div>
      {error && <p className={errorTextClass}>{error}</p>}
      <div className="mt-1 flex justify-end gap-2">
        <button type="button" className={secondaryButtonClass} onClick={reset}>
          取消
        </button>
        <button type="button" className={primaryButtonClass} onClick={handleAdd} disabled={submitting}>
          {submitting ? "新增中…" : "新增"}
        </button>
      </div>
    </div>
  );
}

/** 個人乙位正魂：只填姓名，自動加上「乙位正魂」。 */
function NameAddForm({
  title,
  onAdd,
  onRecordUpdated,
}: {
  title: string;
  onAdd: (payload: {
    displayName: string;
    yangshangName?: string | null;
    notes?: string | null;
  }) => Promise<RecordJSON>;
  onRecordUpdated: (record: RecordJSON) => void;
}) {
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState("");
  const [yangshangName, setYangshangName] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function reset() {
    setAdding(false);
    setError(null);
    setName("");
    setYangshangName("");
    setNotes("");
  }

  async function handleAdd() {
    const trimmedName = name.trim();
    if (!trimmedName) {
      setError("請輸入姓名");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const record = await onAdd({
        displayName: `${trimmedName} 乙位正魂`,
        yangshangName: yangshangName.trim() || null,
        notes: notes.trim() || null,
      });
      onRecordUpdated(record);
      reset();
    } catch (err) {
      setError(err instanceof Error ? err.message : "網路錯誤，請稍後再試一次。");
    } finally {
      setSubmitting(false);
    }
  }

  if (!adding) {
    return (
      <button
        type="button"
        onClick={() => setAdding(true)}
        className="mt-3 w-full rounded-xl bg-white/70 px-4 py-2 text-sm text-ink-soft transition hover:bg-white"
      >
        ＋ 新增{title}
      </button>
    );
  }

  return (
    <div className="mt-3 flex flex-col gap-2 rounded-xl bg-white/80 p-4">
      <div>
        <label className={labelClass}>姓名</label>
        <div className="flex items-center gap-2">
          <input
            className={inputClass}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="例如：王小明"
            autoFocus
          />
          {name.trim() && (
            <span className="whitespace-nowrap text-sm text-ink-faint">
              → {name.trim()} 乙位正魂
            </span>
          )}
        </div>
      </div>
      <div>
        <label className={labelClass}>陽上姓名（選填）</label>
        <input
          className={inputClass}
          value={yangshangName}
          onChange={(e) => setYangshangName(e.target.value)}
        />
      </div>
      <div>
        <label className={labelClass}>備註（選填）</label>
        <input className={inputClass} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </div>
      {error && <p className={errorTextClass}>{error}</p>}
      <div className="mt-1 flex justify-end gap-2">
        <button type="button" className={secondaryButtonClass} onClick={reset}>
          取消
        </button>
        <button type="button" className={primaryButtonClass} onClick={handleAdd} disabled={submitting}>
          {submitting ? "新增中…" : "新增"}
        </button>
      </div>
    </div>
  );
}
