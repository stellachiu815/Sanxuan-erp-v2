// V3.0「普渡登記 UI」共用型別。
//
// 這裡刻意不直接重用 src/lib/ritual.ts 的 Prisma payload 型別，因為從
// Server Component 傳到 Client Component 的資料，一律先經過
// JSON.parse(JSON.stringify(...)) 序列化過（Decimal／Date 都會變成字串），
// 跟 Prisma 原始型別不一樣；之後畫面上每次呼叫 API 存檔，拿到的也是同一種
// JSON 形狀，所以乾脆單獨定義一份「畫面用」的型別，比較單純、不會混淆。

export type EntryCategory =
  | "ANCESTOR_LINE"
  | "INDIVIDUAL_SOUL"
  | "DEBT_CREDITOR"
  | "UNBORN_CHILD";

export type EntryJSON = {
  id: string;
  category: EntryCategory;
  displayName: string;
  yangshangName: string | null;
  notes: string | null;
  sortOrder: number;
};

export type DetailJSON = {
  id: string;
  isRegistered: boolean;
  yangshangName: string | null;
  enshrinementLocation: string | null;
  isSponsor: boolean;
  sponsorQuantity: number | null;
  sponsorUnitPrice: string | null;
  sponsorAmount: string | null;
  sponsorNotes: string | null;
  tableNumber: string | null;
  notes: string | null;
  entries: EntryJSON[];
};

export type RecordJSON = {
  id: string;
  year: number;
  status: "DRAFT" | "CONFIRMED" | "CANCELLED";
  universalSalvation: DetailJSON | null;
};

/**
 * 新增登記項目時的操作模式（V3.1「行政流程優化」新增，只影響畫面上「新增」
 * 這個動作怎麼填，不影響資料表欄位、也不影響任何 API）：
 * - "surname"：只需輸入姓氏，系統自動組成「○○姓歷代祖先」。
 * - "name"：只需輸入姓名，系統自動加上「乙位正魂」。
 * - "instant"：不用輸入任何文字，按一下就直接建立固定名稱的一筆登記
 *   （冤親債主／無緣子女），需要備註時再用既有的「編輯」功能補上。
 */
export type EntryAddMode = "surname" | "name" | "instant";

/** 四個登記分類固定的顯示順序與樣式，畫面上依這個順序排版。 */
export const CATEGORY_SECTIONS: {
  category: EntryCategory;
  title: string;
  tone: string;
  addMode: EntryAddMode;
  /** "instant" 模式下，按一下就直接建立的固定名稱 */
  fixedDisplayName?: string;
}[] = [
  {
    category: "ANCESTOR_LINE",
    title: "歷代祖先",
    tone: "bg-yolk-50",
    addMode: "surname",
  },
  {
    category: "INDIVIDUAL_SOUL",
    title: "個人乙位正魂",
    tone: "bg-blossom-50",
    addMode: "name",
  },
  {
    category: "DEBT_CREDITOR",
    title: "冤親債主",
    tone: "bg-mist-50",
    addMode: "instant",
    fixedDisplayName: "冤親債主",
  },
  {
    category: "UNBORN_CHILD",
    title: "無緣子女",
    tone: "bg-sage-50",
    addMode: "instant",
    fixedDisplayName: "無緣子女",
  },
];
