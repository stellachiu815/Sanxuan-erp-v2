"use client";

import { useState } from "react";
import {
  inputClass,
  labelClass,
  primaryButtonClass,
  secondaryButtonClass,
  errorTextClass,
} from "@/components/household/formStyles";
import EntryRow from "./EntryRow";
import type { EntryCategory, EntryJSON, RecordJSON } from "./types";

type Props = {
  householdId: string;
  year: number;
  category: EntryCategory;
  title: string;
  tone: string;
  placeholder: string;
  entries: EntryJSON[];
  onRecordUpdated: (record: RecordJSON) => void;
};

/** 一個登記分類的區塊（例如「歷代祖先」），列出目前的登記項目、可新增/編輯/刪除。 */
export default function EntryCategorySection({
  householdId,
  year,
  category,
  title,
  tone,
  placeholder,
  entries,
  onRecordUpdated,
}: Props) {
  const [adding, setAdding] = useState(false);
  const [displayName, setDisplayName] = useState("");
  const [yangshangName, setYangshangName] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function resetAddForm() {
    setAdding(false);
    setError(null);
    setDisplayName("");
    setYangshangName("");
    setNotes("");
  }

  async function handleAdd() {
    if (!displayName.trim()) {
      setError("請輸入名稱");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch(
        `/api/households/${householdId}/rituals/universal-salvation/${year}/entries`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            category,
            displayName: displayName.trim(),
            yangshangName: yangshangName.trim() || null,
            notes: notes.trim() || null,
          }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "新增失敗，請稍後再試一次。");
        return;
      }
      onRecordUpdated(data.record);
      resetAddForm();
    } catch {
      setError("網路錯誤，請稍後再試一次。");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className={`rounded-2xl p-5 ${tone}`}>
      <div className="flex items-center justify-between">
        <h3 className="text-base font-medium text-ink">{title}</h3>
        <span className="rounded-full bg-white/70 px-2 py-0.5 text-xs text-ink-soft">
          {entries.length} 筆
        </span>
      </div>

      <div className="mt-3 flex flex-col gap-2">
        {entries.length === 0 && !adding && (
          <p className="text-sm text-ink-faint">尚無登記項目。</p>
        )}
        {entries.map((entry) => (
          <EntryRow
            key={entry.id}
            householdId={householdId}
            year={year}
            entry={entry}
            onRecordUpdated={onRecordUpdated}
          />
        ))}
      </div>

      {adding ? (
        <div className="mt-3 flex flex-col gap-2 rounded-xl bg-white/80 p-4">
          <div>
            <label className={labelClass}>名稱</label>
            <input
              className={inputClass}
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder={placeholder}
              autoFocus
            />
          </div>
          <div>
            <label className={labelClass}>陽上姓名</label>
            <input
              className={inputClass}
              value={yangshangName}
              onChange={(e) => setYangshangName(e.target.value)}
            />
          </div>
          <div>
            <label className={labelClass}>備註</label>
            <input className={inputClass} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
          {error && <p className={errorTextClass}>{error}</p>}
          <div className="mt-1 flex justify-end gap-2">
            <button type="button" className={secondaryButtonClass} onClick={resetAddForm}>
              取消
            </button>
            <button
              type="button"
              className={primaryButtonClass}
              onClick={handleAdd}
              disabled={submitting}
            >
              {submitting ? "新增中…" : "新增"}
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setAdding(true)}
          className="mt-3 w-full rounded-xl bg-white/70 px-4 py-2 text-sm text-ink-soft transition hover:bg-white"
        >
          ＋ 新增{title}
        </button>
      )}
    </div>
  );
}
