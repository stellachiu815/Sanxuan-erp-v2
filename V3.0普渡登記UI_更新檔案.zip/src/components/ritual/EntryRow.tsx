"use client";

import { useState } from "react";
import {
  inputClass,
  labelClass,
  primaryButtonClass,
  secondaryButtonClass,
  errorTextClass,
} from "@/components/household/formStyles";
import type { EntryJSON, RecordJSON } from "./types";

type Props = {
  householdId: string;
  year: number;
  entry: EntryJSON;
  onRecordUpdated: (record: RecordJSON) => void;
};

/** 單一筆登記項目（歷代祖先／個人乙位正魂／冤親債主／無緣子女其中一筆）。 */
export default function EntryRow({ householdId, year, entry, onRecordUpdated }: Props) {
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState(entry.displayName);
  const [yangshangName, setYangshangName] = useState(entry.yangshangName ?? "");
  const [notes, setNotes] = useState(entry.notes ?? "");
  const [submitting, setSubmitting] = useState<"save" | "delete" | null>(null);
  const [error, setError] = useState<string | null>(null);

  function cancelEdit() {
    setEditing(false);
    setError(null);
    setDisplayName(entry.displayName);
    setYangshangName(entry.yangshangName ?? "");
    setNotes(entry.notes ?? "");
  }

  async function handleSave() {
    if (!displayName.trim()) {
      setError("請輸入名稱");
      return;
    }
    setSubmitting("save");
    setError(null);
    try {
      const res = await fetch(
        `/api/households/${householdId}/rituals/universal-salvation/${year}/entries/${entry.id}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            displayName: displayName.trim(),
            yangshangName: yangshangName.trim() || null,
            notes: notes.trim() || null,
          }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "儲存失敗，請稍後再試一次。");
        return;
      }
      onRecordUpdated(data.record);
      setEditing(false);
    } catch {
      setError("網路錯誤，請稍後再試一次。");
    } finally {
      setSubmitting(null);
    }
  }

  async function handleDelete() {
    setSubmitting("delete");
    setError(null);
    try {
      const res = await fetch(
        `/api/households/${householdId}/rituals/universal-salvation/${year}/entries/${entry.id}`,
        { method: "DELETE" }
      );
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "刪除失敗，請稍後再試一次。");
        return;
      }
      onRecordUpdated(data.record);
    } catch {
      setError("網路錯誤，請稍後再試一次。");
    } finally {
      setSubmitting(null);
    }
  }

  if (editing) {
    return (
      <div className="flex flex-col gap-2 rounded-xl bg-white/80 p-4">
        <div>
          <label className={labelClass}>名稱</label>
          <input
            className={inputClass}
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            autoFocus
          />
        </div>
        <div>
          <label className={labelClass}>陽上姓名</label>
          <input
            className={inputClass}
            value={yangshangName}
            onChange={(e) => setYangshangName(e.target.value)}
          />
        </div>
        <div>
          <label className={labelClass}>備註</label>
          <input className={inputClass} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </div>
        {error && <p className={errorTextClass}>{error}</p>}
        <div className="mt-1 flex justify-end gap-2">
          <button type="button" className={secondaryButtonClass} onClick={cancelEdit}>
            取消
          </button>
          <button
            type="button"
            className={primaryButtonClass}
            onClick={handleSave}
            disabled={submitting !== null}
          >
            {submitting === "save" ? "儲存中…" : "儲存"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start justify-between gap-3 rounded-xl bg-white/80 px-4 py-3">
      <div className="min-w-0">
        <p className="text-sm text-ink">{entry.displayName}</p>
        {(entry.yangshangName || entry.notes) && (
          <p className="mt-0.5 text-xs text-ink-faint">
            {entry.yangshangName && <>陽上姓名：{entry.yangshangName}</>}
            {entry.yangshangName && entry.notes && "　"}
            {entry.notes && <>備註：{entry.notes}</>}
          </p>
        )}
        {error && <p className={`mt-1 ${errorTextClass}`}>{error}</p>}
      </div>
      <div className="flex shrink-0 gap-1">
        <button
          type="button"
          onClick={() => setEditing(true)}
          className="rounded-full px-3 py-1.5 text-xs text-ink-soft transition hover:bg-cream-200 hover:text-ink"
        >
          編輯
        </button>
        <button
          type="button"
          onClick={handleDelete}
          disabled={submitting !== null}
          className="rounded-full px-3 py-1.5 text-xs text-ink-soft transition hover:bg-blossom-100 hover:text-ink disabled:opacity-50"
        >
          {submitting === "delete" ? "刪除中…" : "刪除"}
        </button>
      </div>
    </div>
  );
}
