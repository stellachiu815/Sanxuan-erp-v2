// V3.0「普渡登記 UI」共用型別。
//
// 這裡刻意不直接重用 src/lib/ritual.ts 的 Prisma payload 型別，因為從
// Server Component 傳到 Client Component 的資料，一律先經過
// JSON.parse(JSON.stringify(...)) 序列化過（Decimal／Date 都會變成字串），
// 跟 Prisma 原始型別不一樣；之後畫面上每次呼叫 API 存檔，拿到的也是同一種
// JSON 形狀，所以乾脆單獨定義一份「畫面用」的型別，比較單純、不會混淆。

export type EntryCategory =
  | "ANCESTOR_LINE"
  | "INDIVIDUAL_SOUL"
  | "DEBT_CREDITOR"
  | "UNBORN_CHILD";

export type EntryJSON = {
  id: string;
  category: EntryCategory;
  displayName: string;
  yangshangName: string | null;
  notes: string | null;
  sortOrder: number;
};

export type DetailJSON = {
  id: string;
  isRegistered: boolean;
  yangshangName: string | null;
  enshrinementLocation: string | null;
  isSponsor: boolean;
  sponsorQuantity: number | null;
  sponsorUnitPrice: string | null;
  sponsorAmount: string | null;
  sponsorNotes: string | null;
  tableNumber: string | null;
  notes: string | null;
  entries: EntryJSON[];
};

export type RecordJSON = {
  id: string;
  year: number;
  status: "DRAFT" | "CONFIRMED" | "CANCELLED";
  universalSalvation: DetailJSON | null;
};

/** 四個登記分類固定的顯示順序與樣式，畫面上依這個順序排版。 */
export const CATEGORY_SECTIONS: {
  category: EntryCategory;
  title: string;
  tone: string;
  placeholder: string;
}[] = [
  {
    category: "ANCESTOR_LINE",
    title: "歷代祖先",
    tone: "bg-yolk-50",
    placeholder: "例如：王姓歷代祖先",
  },
  {
    category: "INDIVIDUAL_SOUL",
    title: "個人乙位正魂",
    tone: "bg-blossom-50",
    placeholder: "例如：王小明 乙位正魂",
  },
  {
    category: "DEBT_CREDITOR",
    title: "冤親債主",
    tone: "bg-mist-50",
    placeholder: "例如：冤親債主一位",
  },
  {
    category: "UNBORN_CHILD",
    title: "無緣子女",
    tone: "bg-sage-50",
    placeholder: "例如：無緣子女一位",
  },
];
